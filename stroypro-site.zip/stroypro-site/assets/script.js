
const menu=document.querySelector('.menu'), links=document.querySelector('.navlinks');
if(menu) menu.addEventListener('click',()=>links.classList.toggle('open'));
document.querySelectorAll('[data-lead-form]').forEach(form=>{
 form.addEventListener('submit',e=>{
  e.preventDefault();
  const data=new FormData(form);
  const name=data.get('name')||'';
  const phone=data.get('phone')||'';
  const service=data.get('service')||'Консультация';
  const msg=`Здравствуйте! Меня зовут ${name}. Интересует: ${service}. Телефон: ${phone}.`;
  const phoneNumber='996XXXXXXXXX'; // Замените на номер WhatsApp без + и пробелов
  if(phoneNumber==='996XXXXXXXXX'){alert('Замените номер WhatsApp в файле assets/script.js на свой.');return;}
  window.open(`https://wa.me/${phoneNumber}?text=${encodeURIComponent(msg)}`,'_blank');
 });
});
